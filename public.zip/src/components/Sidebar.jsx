import React, { useContext, useEffect, useState } from "react";
import { UserContext } from "../App";

const Sidebar = () => {
  const { Data, setData, tempData, setTempData } = useContext(UserContext);

  const filterData = {
    Color: [
      "Red",
      "Blue",
      "Green",
      "Black",
      "Pink",
      "Grey",
      "White",
      "Purple",
      "Yellow",
    ],
    Gender: ["Men", "Women"],
    // Price: ["0-Rs250", "Rs251-450", "Rs 450"],
    Type: ["Polo", "Hoodie", "Basic"],
  };

  const [selectedFilter, setSelectedFilter] = useState({
    Color: "",
    Gender: "",
    Price: "",
    Type: "",
  });

  useEffect(() => {
    let selectedItems = [...tempData];
    for (var key in selectedFilter) {
      if (selectedFilter[key] !== "") {
        console.log("pass");
        selectedItems = selectedItems.filter((item) => {
          item[key] === selectedFilter[key];
        });
        // console.log(selectedFilter[key]);
      }
    }
    // const k = "type";
    // console.log(Data.filter((item) => item[k] === "Hoodie"));
    console.log(selectedItems, selectedFilter, "hello");
    setData(selectedItems);
    // for (var key in selectedFilter) {
    //   console.log(selectedFilter[key]);
    // }
  }, [selectedFilter]);

  const handleChange = (event) => {
    const { name, value, checked } = event.target;
    setSelectedFilter((prevState) => {
      return { ...prevState, [name]: checked ? value : "" };
    });
  };
  // const handleChange = (event) => {
  //   const { name, value } = event.target;
  //   if(event.target.checked) {
  //     setSelectedFilter((prevState) => {
  //       return { ...prevState, [name]: event.target.checked?value:"" };
  //     });
  //   } else {
  //     setSelectedFilter((prevState) => {
  //       return { ...prevState, [name]: "" };
  //     });
  //   }
  // };

  return (
    <div className="gap-2 shadow-lg rounded-sm p-4 pl-8 hidden sm:block h-fit mt-20 w-[18rem] sticky left-22 top-44">
      {Object.entries(filterData).map((data, i) => {
        return (
          <div className="py-1" key={i}>
            <h1 className="font-bold text-black">{data[0]}</h1>
            {data[1].map((option, index) => {
              return (
                <div key={index}>
                  <input
                    type="checkbox"
                    name={data[0]}
                    value={option}
                    checked={selectedFilter[data[0]] === option}
                    onChange={handleChange}
                  />
                  <label className="font-semibold text-sm ml-2">{option}</label>
                </div>
              );
            })}
          </div>
        );
      })}
    </div>
  );
};

export default Sidebar;
